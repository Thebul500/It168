/*
 *  Filename:  Problem7.java
 *  
 *  Programmer: Cathy Holbrook
 *  ULID:  cjholbr
 *
 *  Date:  
 *
 *  Class: IT 168
 *
 *  Lecture Section:
 *  Lecture Instructor:
 *  Lab Section: 
 *  Lab Instructor: 
 */
package edu.ilstu;

import java.util.Scanner;

/**
 * Code for part 4
 *
 * @author Sannan Iqbal
 *
 */
public class Triangle
{

	public static void main(String[] args)
	{
		System.out.println("Enter the size of a triangele from integers from 1 -50 ");
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		while (n < 0 || n > 50)
		{
		    System.out.print("Size must be between 0 and 50. Try again: ");
		    n = s.nextInt();
		}		
		
		for (int j = 0; j <=n; j++)
		{
			for (int i = 0;i<j;i++ )
				System.out.println("* ");
		}
			System.out.println("");
		for(int i = 0;i>n;i--){
			
			for (int f = 0; f > i; f--)
		{
			System.out.println("*");
		}
		System.out.println("*");
	}
}}


